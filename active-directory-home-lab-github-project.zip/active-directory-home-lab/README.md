# Windows Server 2022 Active Directory Home Lab

## Project Overview

This project documents a Windows Server 2022 home lab built in VirtualBox to develop practical junior systems administrator skills.

The environment simulates a small business network using the `contoso.local` Active Directory domain. It includes centralized identity management, DNS, DHCP, Group Policy, department file shares, DFS, Windows Server Backup, WSUS, and PowerShell administration.

The project also documents troubleshooting decisions made during the build. The goal is to demonstrate not only successful configuration, but also the ability to diagnose and resolve common infrastructure problems.

## Lab Environment

| Component | Configuration |
|---|---|
| Hypervisor | Oracle VirtualBox |
| Domain Controller | Windows Server 2022 Desktop Experience |
| Domain Controller Name | DC01 |
| Client Computer | Windows 10 |
| Client Computer Name | PC01 |
| Active Directory Domain | `contoso.local` |
| DNS | Active Directory-integrated DNS |
| DHCP | Windows Server DHCP |
| File Services | SMB shares, NTFS permissions, DFS Namespace |
| Update Management | Windows Server Update Services |
| Backup | Windows Server Backup to a secondary virtual disk |

## Architecture

```text
                         VirtualBox
                             |
                +------------+------------+
                |                         |
          Windows Server 2022        Windows 10
                DC01                    PC01
                |                         |
        +-------+--------+                |
        |       |        |                |
       AD DS   DNS      DHCP              |
        |       |        |                |
        +-------+--------+----------------+
                |
          contoso.local
                |
     +----------+-----------+
     |          |           |
   Sales      Finance       IT
     |          |           |
  File Share  File Share  File Share
     \          |          /
      \         |         /
       DFS: \\contoso.local\Shares
```

## Skills Demonstrated

- Installing and configuring Windows Server 2022
- Deploying Active Directory Domain Services
- Creating and managing users, groups, and Organizational Units
- Configuring Active Directory-integrated DNS
- Installing and authorizing DHCP
- Creating and managing DHCP scopes and leases
- Joining Windows clients to a domain
- Configuring SMB shares and hidden shares
- Applying Share and NTFS permissions
- Creating and linking Group Policy Objects
- Deploying mapped drives through Group Policy Preferences
- Applying workstation security settings
- Deploying a desktop wallpaper through Group Policy
- Configuring password and screen-lock policies
- Managing Active Directory with PowerShell
- Creating a DFS Namespace
- Configuring Windows Server Backup
- Installing and configuring WSUS
- Configuring WSUS clients through Group Policy
- Troubleshooting networking, Group Policy, permissions, DFS, and PowerShell issues

## Repository Structure

```text
active-directory-home-lab/
├── README.md
├── LICENSE
├── .gitignore
├── docs/
│   ├── 01-environment-and-server-installation.md
│   ├── 02-active-directory-and-dns.md
│   ├── 03-users-groups-and-ous.md
│   ├── 04-domain-join.md
│   ├── 05-file-shares-and-permissions.md
│   ├── 06-group-policy.md
│   ├── 07-powershell-administration.md
│   ├── 08-dhcp.md
│   ├── 09-dfs-namespace.md
│   ├── 10-windows-server-backup.md
│   ├── 11-wsus.md
│   ├── 12-troubleshooting.md
│   └── 13-future-hybrid-roadmap.md
├── scripts/
│   ├── README.md
│   └── ad-user-management.ps1
└── screenshots/
    └── README.md
```

## Major Milestones

### Identity and Core Infrastructure
- Installed Windows Server 2022 Desktop Experience
- Renamed the server to `DC01` before promotion
- Installed Active Directory Domain Services and DNS
- Created the `contoso.local` forest
- Joined `PC01` to the domain

### Active Directory Administration
- Created a structured OU design
- Created department security groups
- Created and managed users
- Practiced enabling, disabling, and creating accounts with PowerShell

### File and Policy Management
- Created Sales, Finance, and IT department shares
- Configured Share and NTFS permissions
- Created hidden shares
- Deployed mapped drives using Group Policy
- Configured workstation policies
- Deployed a corporate wallpaper
- Disabled Control Panel access
- Configured password-protected screen saver settings

### Network Services
- Installed and authorized DHCP
- Created a working DHCP scope
- Confirmed that PC01 received a DHCP lease
- Created the DFS namespace `\\contoso.local\Shares`

### Operations
- Added a secondary virtual disk
- Installed Windows Server Backup
- Configured a System State backup
- Installed and configured WSUS
- Configured PC01 to report to WSUS through Group Policy

## Troubleshooting Highlights

This project includes documented solutions for Server Core installation, domain controller naming, Windows 11 virtual hardware requirements, VirtualBox networking, APIPA addressing, DNS, GPO scope, drive mapping, wallpaper permissions, PowerShell syntax, DFS access, backup storage, WSUS policy validation, and internet-access planning.

See [docs/12-troubleshooting.md](docs/12-troubleshooting.md) for the full troubleshooting log.

## Screenshots

Screenshots were not captured during every stage of the original build. The `screenshots` folder contains a checklist of final-state screenshots that can be added later without rebuilding the entire lab.

## Future Development

- Restore outbound internet access through VirtualBox NAT
- Add a routable UPN suffix
- Create a Microsoft Entra ID test tenant
- Learn Microsoft 365 administration
- Deploy Microsoft Entra Connect Sync on a member server
- Synchronize selected users and groups
- Explore Microsoft Intune
- Build Azure networking and virtual machine labs

## Portfolio Use

This repository is designed to support applications for roles such as Junior Systems Administrator, Windows Systems Administrator, IT Support Specialist, Infrastructure Support Technician, Microsoft 365 Administrator, and Hybrid Cloud Support Associate.
