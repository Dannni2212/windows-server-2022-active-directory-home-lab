# PowerShell Scripts

This folder contains safe examples based on the lab.

Before running a script:
1. Review every command.
2. Test with non-production accounts.
3. Replace example values.
4. Never commit passwords or credentials.
5. Use `-WhatIf` where supported.
